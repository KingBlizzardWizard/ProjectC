#include <stdio.h>
void printString(char*);
void printChar(char);
void readString(char*);
void readSector(char* buffer, int sector);
void handleInterrupt21(int ax, int bx, int cx, int dx);
void readFile(char* fileName, char* buffer);
void executeProgram(char* name);
void terminate();


int main(){

char b[13312];
//readSector(b,30);
int sectorsRead;
makeInterrupt21();

//readFile("messag",b);

//printString(b);

//MESSAGE INTERRUPT
//interrupt(0x21, 3, "messa2",b, &sectorsRead);
//printString(b);


//THE ONLY THING THAT DOESNT WORK IS DOING THIS ODD IF STATEMENT
//printString("after first interrupt");
//if (sectorsRead>0){
//	printString("inside");
//	interrupt(0x21,0,b,0,0);
//}else{
//	interrupt(0x21,0,"Blah",0,0);
//}
printString("Pre-Interrupt");
interrupt(0x21,5, "tstpr2", 0, 0);


printString("KMS");
	while(1);//This will ALWAYS be the last thing until ProjE
}



void printChar(char letter){
	int i = 0;
//	for(i;i<10;i++){
	interrupt(0x10, 0xe*256+letter, 0, 0, 0);
//	}
}

void printString(char* chars){
	int i = 0;
	while(chars[i]!= 0x0)
	{
		interrupt(0x10, 0xe*256+chars[i], 0, 0, 0);
		i++;
	}
	interrupt(0x10, 0xe*256+0x0a,0,0,0);
	interrupt(0x10, 0xe*256+0xd,0,0,0);
}

void readString(char* line){
	int i = 0;

	while(1){//While loop Open
		line[i] = interrupt(0x16, 0, 0, 0, 0);

//If enter is pressed
		if(line[i]==0xd){//Enter If open
			printChar(0xd);
			printChar(0xa);
			printString(line);
			break;
		}//Enter If Closed
		else if(line[i]==0x8){//BackSpace if open
			if(i==0){//0 condition open
				printString("Forever Gone");
			}//zero conditon close
			else{
				printChar(0x8);
				printChar(' ');
				printChar(0x8);
				i--;
			}//else close
		}//backspace close
		else{
			printChar(line[i]);
			i++;
		}
	}//While loop close
}//Function Close

void readSector(char* buffer, int sector){
	interrupt(0x13,2*256+1,buffer,0*256+(sector+1),0*256+0x80);
}

void readFile(char* fileName, char* buffer){
	char dir[512];
	int i = 0;
	int j = 0;
	int sectorsRead = 0;
	int fileEntry = 0;

	readSector(dir,2);

	for (fileEntry; fileEntry<512; fileEntry+=32){
		//printString(dir+fileEntry);
		if(fileName[0]==dir[fileEntry+0] && fileName[1]==dir[fileEntry+1] && fileName[2]==dir[fileEntry+2] && fileName[3]==dir[fileEntry+3] && fileName[4]==dir[fileEntry+4] && fileName[5]==dir[fileEntry+5]){
			//sectorsRead++;
			while(dir[fileEntry+6+sectorsRead]!=0x0){
				sectorsRead++;
			}


			for(i;i<sectorsRead;i++){
				readSector(buffer+(i*512),dir[fileEntry+6+i]);
			}//Close nested loop

		}else{
			sectorsRead = 0;
//			break;
		}//Close if/else

	}//Close the for loop

}//Close the function


void executeProgram(char* name){
	char b[13312];
	int i=0;
	printString("executeProgram ran");
	readFile(name, b);//IS THIS SUPPOSED TO ONLY HAVE ONE PARAMENTER?

//	readString(name);
//	printString(name);

	printString("file found",name);
	for(i;i<13312;i++){//THIS IS THE MAX SIZE HARRD CODED, MAY CAUSE ERRROS IF SAMLLER!!!
		putInMemory(0x2000, i, b[i]);
	}
	printString("Launching program");
	launchProgram(0x2000);

}


void terminate(){
	char shellName[6];
	shellName[0]='s';
	shellName[1]='h';
	shellName[2]='e';
	shellName[3]='l';
	shellName[4]='l';
	shellName[5]= '\0';

	executeProgram();
}

void handleInterrupt21(int ax, int bx, int cx, int dx){
        if(ax==0){
                printString(bx);
        }else if (ax==1){
                readString(bx);
        }else if (ax==2){
                readSector(bx,dx);
        }else if (ax==3){
                readFile(bx,cx);//cx not dx?
        }else if (ax==4){
		executeProgram(bx);
	}else if (ax==5){
		terminate();
	}else{
                printString("And now they're, see now they're gone, forever gone");
	}
}
