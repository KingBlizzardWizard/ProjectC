//Owen and Joao
#include <stdio.h>

int main(){
	char buffer[512];
	char z[32];
	int i;
//	char* z;
//	char* y= "printString";

	while(1){
		syscall(0,"Severa >");
//		syscall(0,"Cynthia");
//		syscall(0,z);
		syscall(1,z);
//		syscall(0,z);
			
		// detect load command
		if (z[0] == 'l' && z[1] == 'o' && z[2] == 'a' && z[3] == 'd'){
			char y[7];

			for(i;i<512;i++){
				buffer[i] = NULL;
			}

			y[0]=z[5];
			y[1]=z[6];
			y[2]=z[7];
			y[3]=z[8];
			y[4]=z[9];
			y[5]=z[10];
			y[6]='\0';

			syscall(3,y,buffer);

			if(buffer[0] != NULL)
				syscall(0,buffer);
			else
				syscall(0, "file not found");

			for(i;i<512;i++){
				buffer[i] = NULL;
			}
			i=0;
			break;
		}else if (z[0] == 'e' && z[1] == 'x' && z[2] == 'e' && z[3] == 'c'){
			char y[7];

			for(i;i<512;i++){
				buffer[i] = NULL;
			}
			i=0;
			for(i;i<7;i++){
				y[i] = NULL;
			}
			i=0;
//			for(i=5;i<32;i++){
//				z[i] = NULL;
//			}


			y[0]=z[5];
			y[1]=z[6];
			y[2]=z[7];
			y[3]=z[8];
			y[4]=z[9];
			y[5]=z[10];
			y[6]='\0';
			syscall(3,y,buffer);

			if (buffer[0] != NULL){
				syscall(4,y);
				for (i;i<7;i++){
					y[i]= NULL;
				}
				i=0;
				for(i;i<512;i++){
					buffer[i] = NULL;
				}
				i=0;
			}else{
				syscall(0,"program not found");
			}
			for(i;i<512;i++){
				buffer[i] = NULL;
			}
			i=0;
			break;


		}else{
			syscall(0, "Grima");
			break;
		}
	}


	for(i;i<512;i++){
		buffer[i] = NULL;
	}
	i=0;
	for (i;i<32;i++){
		z[i]= NULL;
	}
	i=0;

	syscall(5);
}
