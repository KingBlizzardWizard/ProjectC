dd if=/dev/zero of=diskc.img bs=512 count=256
nasm bootload.asm
dd if=bootload of=diskc.img conv=notrunc
bcc -c -ansi -o shell_c.o shell.c
as86 userlib.asm -o userlib_asm.o
ld86 -o shell -d shell_c.o userlib_asm.o
gcc -o loadFile loadFile.c
./loadFile shell

cd ~/Downloads
java -jar simulator.jar
