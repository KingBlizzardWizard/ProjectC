dd if=/dev/zero of=diskc.img bs=512 count=256
nasm bootload.asm
dd if=bootload of=diskc.img conv=notrunc

bcc -c -ansi -o kernel_c.o kernel.c
as86 kernel.asm -o kernel_asm.o
ld86 -o kernel -d kernel_c.o kernel_asm.o
#gcc -o loadFile loadFile.c

bcc -c -ansi -o shell_c.o shell.c
as86 userlib.asm -o userlib_asm.o
ld86 -o shell -d shell_c.o userlib_asm.o
gcc -o loadFile loadFile.c

#bcc -ansi -c -o tstpr1.o tstpr1.c
#as86 -o userlib.o userlib.asm
#ld86 -d -o tstpr1 tstpr1.o userlib.o

#bcc -ansi -c -o tstpr2.o tstpr2.c
#as86 -o userlib.o userlib.asm
#ld86 -d -o tstpr2 tstpr2.o userlib.o



#dd if=kernel of=diskc.img bs=512 conv=notrunc seek=3
./loadFile kernel
./loadFile shell
#dd if=message.txt of=diskc.img bs=512 count=1 seek=20 conv=notrunc
./loadFile message.txt
#./loadFile Wuthering.txt

#./loadFile tstpr1
./loadFile tstpr2



./loadFile message.txt
./loadFile messa2.txt


cd ~/Downloads
java -jar simulator.jar
